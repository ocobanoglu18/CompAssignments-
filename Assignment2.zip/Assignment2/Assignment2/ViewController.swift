//
//  ViewController.swift
//  Assignment2
//
//  Created by Adnan Cobanoglu on 13.10.2021.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var GuessNumber: UITextField!
    @IBOutlet weak var RealNumber: UILabel!
 
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        RealNumber.isHidden=true
        
    }

    @IBAction func myButton(_ sender: Any) {
        
        let firstValue = Int(GuessNumber.text!)
        let secondValue=Int.random(in: 0...10)
        RealNumber.isHidden=false
        
        
        
        if firstValue==secondValue{
            RealNumber.text="You won!!!"
        }else {
            RealNumber.text="Try Again"
            RealNumber.text="the answer is \(secondValue) ."
        }
    }
    
 
        
        
    
    
    
}

