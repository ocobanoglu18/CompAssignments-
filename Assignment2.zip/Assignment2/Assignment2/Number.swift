//
//  Number.swift
//  Assignment2
//
//  Created by Adnan Cobanoglu on 13.10.2021.
//

import Foundation



