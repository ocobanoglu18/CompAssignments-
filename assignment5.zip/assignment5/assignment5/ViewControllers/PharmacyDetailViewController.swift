//
//  PharmacyDetailViewController.swift
//  assignment5
//
//  Created by Adnan Cobanoglu on 18.11.2021.
//

import UIKit

class PharmacyDetailViewController: UIViewController {
    
    var selectedPharmacy:String?
    var cityDataSource:CityDataSource?
    
    
    @IBOutlet weak var pharmacyName: UILabel!
    @IBOutlet weak var pharmacyAdress: UILabel!
    @IBOutlet weak var pharmacyPhone: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.cityDataSource?.delegate=self
        self.cityDataSource?.loadPharmacyDetailList(pharmacyId: self.selectedPharmacy!)

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension PharmacyDetailViewController: CityDataSourceDelegate{
    
    func pharmacyDetailListLoaded(pharmacyDetail: PharmacyDetail) {
        self.pharmacyName.text=pharmacyDetail.Name
        self.pharmacyPhone.text=pharmacyDetail.Phone
        self.pharmacyAdress.text=pharmacyDetail.Address
        
    }
    
 
    func pharmacyListLoaded() {
        
        
        
        }
    func cityListLoaded() {
    
    }

    func regionListLoaded() {
    
    }
}
