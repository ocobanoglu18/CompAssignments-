//
//  PharmacyViewController.swift
//  assignment5
//
//  Created by Adnan Cobanoglu on 18.11.2021.
//

import UIKit

class PharmacyViewController: UIViewController{
    
    @IBOutlet weak var pharmacyTableView: UITableView!
    var cityDataSource:CityDataSource?
    var selectedRegion: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.cityDataSource?.delegate=self
        self.cityDataSource?.loadPharmacyList(regionID: self.selectedRegion!)

        // Do any additional setup after loading the view.
    }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let cell = sender as! PharmacyTableViewCell
        if let indexPath = self.pharmacyTableView.indexPath(for: cell){
                    let pharmacy_detail = self.cityDataSource?.getPharmacyForIndex(index: indexPath.row)
                    let pharmacyDetailViewController = segue.destination as! PharmacyDetailViewController
            pharmacyDetailViewController.selectedPharmacy = pharmacy_detail?.Id
                    pharmacyDetailViewController.cityDataSource = self.cityDataSource
                }
        
    }
    

}
extension PharmacyViewController:CityDataSourceDelegate{
    func pharmacyDetailListLoaded(pharmacyDetail: PharmacyDetail) {
        
    }
    
 
    func pharmacyListLoaded() {
        pharmacyTableView.reloadData()
        
        }
    func cityListLoaded() {
    
    }

    func regionListLoaded() {
    
    }
    
}


extension PharmacyViewController:UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (cityDataSource?.getNumberOfPharmacy())!
        
       
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PharmacyCell", for: indexPath) as! PharmacyTableViewCell
        if let pharmacyDetail=cityDataSource?.getPharmacyForIndex(index:indexPath.row)
        {
            cell.pharmacyLabel.text=pharmacyDetail.Name
            
        }
        return cell
        }
    }
