//
//  CityViewController.swift
//  assignment5
//
//  Created by Adnan Cobanoglu on 17.11.2021.
//

import UIKit

class CityViewController: UIViewController {
    
    let cityDataSource = CityDataSource()
    
    @IBOutlet weak var cityTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        cityDataSource.loadCityList()
        cityDataSource.delegate=self

        // Do any additional setup after loading the view.
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let cell = sender as! CityTableViewCell
                if let indexPath = self.cityTableView.indexPath(for: cell){
                    let city = self.cityDataSource.getCityForIndex(index: indexPath.row)
                    let cityDetailViewController = segue.destination as! CityDetailViewController
                    cityDetailViewController.selectedCityId = city.Id
                    cityDetailViewController.cityDataSource = self.cityDataSource
                }
    }
    

  
}
extension CityViewController:CityDataSourceDelegate{
    func regionListLoaded() {
        
    }
    
    func pharmacyListLoaded() {
        
    }
    
    func pharmacyDetailListLoaded(pharmacyDetail: PharmacyDetail) {
        
    }
    
    func cityListLoaded() {
        cityTableView.reloadData()
    }
    
   
}


extension CityViewController:UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return cityDataSource.getNumberOfCity()
       
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CityCell", for: indexPath) as! CityTableViewCell
        let city=cityDataSource.getCityForIndex(index:indexPath.row)
        cell.CityNameLabel.text=city.Name
        return cell
    }
    
    
}
