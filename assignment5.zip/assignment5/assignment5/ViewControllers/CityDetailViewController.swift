//
//  CityDetailViewController.swift
//  assignment5
//
//  Created by Adnan Cobanoglu on 17.11.2021.
//

import UIKit

class CityDetailViewController: UIViewController {
    @IBOutlet weak var detailTableView: UITableView!
    var selectedCityId: Int?
    var cityDataSource:CityDataSource?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cityDataSource?.delegate=self
        cityDataSource?.loadRegionList(cityID : selectedCityId!)
        // Do any additional setup after loading the view.
    }
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let cell = sender as! CityDetailTableViewCell
                if let indexPath = self.detailTableView.indexPath(for: cell){
                    let region = self.cityDataSource?.getRegionForIndex(index: indexPath.row)
                    let pharmacyViewController = segue.destination as! PharmacyViewController
                    pharmacyViewController.selectedRegion = region?.Id
                    pharmacyViewController.cityDataSource = self.cityDataSource
                }
    }
    

}
extension CityDetailViewController:CityDataSourceDelegate{
    func regionListLoaded() {
        detailTableView.reloadData()
    }
    
    func pharmacyListLoaded() {
        
    }
    
    func pharmacyDetailListLoaded(pharmacyDetail: PharmacyDetail) {
        
    }
    
    func cityListLoaded() {
        
    }
    
    
}
extension CityDetailViewController:UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (cityDataSource?.getNumberOfRegion())!
       
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CityDetailCell", for: indexPath) as! CityDetailTableViewCell
        if let cityDetail = cityDataSource?.getRegionForIndex(index:indexPath.row)
        {
            cell.regionLabel.text=cityDetail.Name
            
        }
        return cell
        }
    }

