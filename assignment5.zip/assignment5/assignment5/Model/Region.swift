//
//  Region.swift
//  assignment5
//
//  Created by Adnan Cobanoglu on 18.11.2021.
//

import Foundation
struct Region:Decodable{
    let Id:String
    let Name:String
}
