//
//  Pharmacy.swift
//  assignment5
//
//  Created by Adnan Cobanoglu on 18.11.2021.
//

import Foundation
struct Pharmacy:Decodable{
    let Id:String
    let Name:String
}

struct PharmacyDetail: Decodable{
    let Name:String
    let Address: String
    let Phone: String
}
