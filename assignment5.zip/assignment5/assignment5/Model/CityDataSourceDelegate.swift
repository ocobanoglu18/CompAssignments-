//
//  CityDataSourceDelegate.swift
//  assignment5
//
//  Created by Adnan Cobanoglu on 17.11.2021.
//

import Foundation

protocol CityDataSourceDelegate{
    func cityListLoaded()
    func regionListLoaded()
    func pharmacyListLoaded()
    func pharmacyDetailListLoaded(pharmacyDetail:PharmacyDetail)
   
}
