//
//  CityDataSource.swift
//  assignment5
//
//  Created by Adnan Cobanoglu on 17.11.2021.
//

import Foundation

class CityDataSource{
    
    private var cityList:[City] = []
    private var regionList:[Region]=[]
    private var pharmacyList:[Pharmacy]=[]
    
    private let baseURL="https://koc.api.staging.tarentum.io"
    var delegate: CityDataSourceDelegate?
    
    
    
    init(){

    }
    
    func getNumberOfCity() -> Int{
        return self.cityList.count
    }
    
    func getCityForIndex(index: Int)->City{
        return self.cityList[index]
    }
    
    func getNumberOfRegion() -> Int{
        return self.regionList.count
    }
    
    func getRegionForIndex(index: Int)->Region{
        return self.regionList[index]
    }
    
    func getNumberOfPharmacy() -> Int{
        return self.pharmacyList.count
    }
    
    func getPharmacyForIndex(index: Int)->Pharmacy{
        return self.pharmacyList[index]
    }
    
    
    
    func loadCityList(){
        let urlSession=URLSession.shared
        if let url=URL(string: "\(baseURL)/city"){
        var urlRequest=URLRequest(url: url)
            urlRequest.httpMethod="GET"
            urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
            let dataTask=urlSession.dataTask(with: urlRequest){data, response, error in
                if let data = data {
                    let decoder=JSONDecoder()
                    let cityArrayFromNetwork=try! decoder.decode([City].self, from: data)
                    self.cityList=cityArrayFromNetwork
                    DispatchQueue.main.async {
                        self.delegate?.cityListLoaded()
                    }
                }
            }
            dataTask.resume()
            
        }
    }

    func loadRegionList(cityID:Int){
        let urlSession=URLSession.shared
        if let url=URL(string: "\(baseURL)/city/\(cityID)/region"){
        var urlRequest=URLRequest(url: url)
            urlRequest.httpMethod="GET"
            urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
            let dataTask=urlSession.dataTask(with: urlRequest){data, response, error in
                if let data = data {
                    let decoder=JSONDecoder()
                    let regionArrayFromNetwork = try! decoder.decode([Region].self, from: data)
                    self.regionList=regionArrayFromNetwork
                    DispatchQueue.main.async {
                        self.delegate?.regionListLoaded()
                    }
                }
            }
            dataTask.resume()
            
        }
    }
    func loadPharmacyList(regionID:String){
        let urlSession=URLSession.shared
        if let url=URL(string: "\(baseURL)/region/\(regionID)/pharmacy"){
        var urlRequest=URLRequest(url: url)
            urlRequest.httpMethod="GET"
            urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
            let dataTask=urlSession.dataTask(with: urlRequest){data, response, error in
                if let data = data {
                    let decoder=JSONDecoder()
                    let pharmacyArrayFromNetwork=try! decoder.decode([Pharmacy].self, from: data)
                    self.pharmacyList=pharmacyArrayFromNetwork
                    DispatchQueue.main.async {
                        self.delegate?.pharmacyListLoaded()
                    }
                }
            }
            dataTask.resume()
            
        }
    }
    func loadPharmacyDetailList(pharmacyId:String){
        let urlSession=URLSession.shared
        if let url=URL(string: "\(baseURL)/pharmacy/\(pharmacyId)"){
        var urlRequest=URLRequest(url: url)
            urlRequest.httpMethod="GET"
            urlRequest.addValue("application/json", forHTTPHeaderField: "Content-Type")
            let dataTask=urlSession.dataTask(with: urlRequest){data, response, error in
                if let data = data {
                    let decoder=JSONDecoder()
                    let pharmacyDetailFromNetwork=try! decoder.decode(PharmacyDetail.self, from: data)
            
                    DispatchQueue.main.async {
                        self.delegate?.pharmacyDetailListLoaded(pharmacyDetail:pharmacyDetailFromNetwork)
                    }
                }
            }
            dataTask.resume()
            
        }
    }
    
    
    
    
}
