//
//  City.swift
//  assignment5
//
//  Created by Adnan Cobanoglu on 15.11.2021.
//

import Foundation
struct City:Decodable {
    let Id: Int
    let Name: String
    
    
}
