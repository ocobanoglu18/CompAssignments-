//
//  CityDetailTableViewCell.swift
//  assignment5
//
//  Created by Adnan Cobanoglu on 18.11.2021.
//

import UIKit

class CityDetailTableViewCell: UITableViewCell {
    @IBOutlet weak var regionLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
