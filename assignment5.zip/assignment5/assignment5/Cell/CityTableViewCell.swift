//
//  CityTableViewCell.swift
//  assignment5
//
//  Created by Adnan Cobanoglu on 17.11.2021.
//

import UIKit

class CityTableViewCell: UITableViewCell {

    @IBOutlet weak var CityImageView: UIImageView!
    @IBOutlet weak var CityNameLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
