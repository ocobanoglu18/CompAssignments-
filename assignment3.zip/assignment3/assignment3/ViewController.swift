//
//  ViewController.swift
//  assignment3
//
//  Created by Adnan Cobanoglu on 29.10.2021.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

