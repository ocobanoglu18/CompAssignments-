//
//  Team.swift
//  assignment4
//
//  Created by Adnan Cobanoglu on 7.11.2021.
//

import Foundation
struct Team{
    let fullName: String
    let imageName: String
    let score: Int
}
