//
//  TeamDataSource.swift
//  assignment4
//
//  Created by Adnan Cobanoglu on 7.11.2021.
//

import Foundation
struct TeamDataSource {
    private var teamList: [Team] = []
    
    init() {
        teamList.append(Team(fullName: "Fenerbahce", imageName: "fenerbahce", score: 20))
        teamList.append(Team(fullName: "Galatasaray", imageName: "galatasaray", score: 22))
        teamList.append(Team(fullName: "Besiktas", imageName: "besiktas", score: 21))
        teamList.append(Team(fullName: "Trabzonspor", imageName: "trabzon", score: 30))
        teamList.append(Team(fullName: "Sivasspor", imageName: "sivasspor", score: 18))
        teamList.append(Team(fullName: "Rizespor", imageName: "rizespor", score: 8))
        teamList.append(Team(fullName: "Konyaspor", imageName: "konyaspor", score: 11))
    }
    
    func getNumberOfTeams() -> Int {
        return teamList.count
    }
    
    func getTeamForIndex(index: Int) -> Team {
        let realIndex = index % teamList.count
        return teamList[realIndex]
    }
}
