//
//  TableViewController.swift
//  assignment4
//
//  Created by Adnan Cobanoglu on 7.11.2021.
//

import UIKit

class TableViewController: UIViewController {
    let teamDataSource = TeamDataSource()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    

}

extension TableViewController: UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return teamDataSource.getNumberOfTeams()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell=tableView.dequeueReusableCell(withIdentifier: "TeamCell", for: indexPath) as! TeamsTableViewCell
        let team=teamDataSource.getTeamForIndex(index: indexPath.row)
        cell.teamImageView.image=UIImage(named: team.imageName)
        cell.teamNameLabel.text=team.fullName
        
        return cell
    }
    
    

    
}
