//
//  CollectionViewController.swift
//  assignment4
//
//  Created by Adnan Cobanoglu on 7.11.2021.
//

import UIKit

class CollectionViewController: UIViewController {

    let teamDataSource=TeamDataSource()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
}

extension CollectionViewController:UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return teamDataSource.getNumberOfTeams()
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell=collectionView.dequeueReusableCell(withReuseIdentifier: "NewTeamCell", for: indexPath) as! NewTeamCollectionViewCell
        let team=teamDataSource.getTeamForIndex(index:indexPath.row)
        cell.TeamImageView.image=UIImage(named:team.imageName)
        cell.TeamNameLabel.text=team.fullName
        return cell
    }
    
    
}



