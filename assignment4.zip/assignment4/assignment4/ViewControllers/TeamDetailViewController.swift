//
//  TeamDetailViewController.swift
//  assignment4
//
//  Created by Adnan Cobanoglu on 7.11.2021.
//

import UIKit

class TeamDetailViewController: UIViewController {
    var selectedTeam: Team?
    @IBOutlet weak var teamImageView: UIImageView!
    @IBOutlet weak var scoreLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        if let team = selectedTeam {
            self.title = team.fullName
            self.teamImageView.image = UIImage(named: team.imageName)
            self.scoreLabel.text = "\(team.score)"
        }

    }
}
