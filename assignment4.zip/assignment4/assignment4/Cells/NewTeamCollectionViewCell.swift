//
//  NewTeamCollectionViewCell.swift
//  assignment4
//
//  Created by Adnan Cobanoglu on 8.11.2021.
//

import UIKit

class NewTeamCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var TeamImageView: UIImageView!
    @IBOutlet weak var TeamNameLabel: UILabel!
}
